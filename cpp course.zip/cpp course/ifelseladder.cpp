#include<iostream>
using namespace std;
int main()
{
    int age;
    cout<<"enter your age";
    cin>>age;
    if(age<18)
    {
        cout<<"you cannot come to the party";
    }
    else if(age==18)
    {
      cout<<"you are kid and you will get a kid pass";
    }
    else if(age<0)
    {
        cout<<"you are not born.........";
    }
    else{
        cout<<"you can come  o the party!!!!";
    }
    return 0;
}