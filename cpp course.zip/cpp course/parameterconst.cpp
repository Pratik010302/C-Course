#include<iostream>
using namespace std;

class Point
{
    int x,y;
    public:
    Point(int a,int b)
    {
        x=a;
        y=b;

    }

    void displaypoint()
    {
        cout<<"the point is:("<<x<<","<<y<<")"<<endl;
    }
};

int main()
{
    int n1,n2;
    cout<<"enter the point 1"<<endl;
    cin>>n1;
    cout<<"enter the point 2:"<<endl;
    cin>>n2;
    Point p(n1,n2);
    p.displaypoint();
    
    return 0;
}