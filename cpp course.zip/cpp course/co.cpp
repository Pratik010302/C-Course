#include<iostream>
using namespace std;

class Employee
{
    private:
    int eid;
    int sal;

    public:
    string ename;
    string place;

    void setdata(int empid, int salary);
    void getdata()
    {
         cout<<"\nthe id of the employee is:"<<eid;
         cout<<"\nthe salary of the employee is:"<<sal;
         cout<<"\nthe name of the employee is:"<<ename;
         cout<<"\nthe location of the employee is:"<<place;

    }


};

void Employee::setdata(int empid,int salary)
{
    eid=empid;
    sal=salary;

}


int main()
{
    Employee e1;
    e1.ename="Pratik";
    e1.place="Dhule";

    e1.setdata(101,50000);
    e1.getdata();
    return 0;
}