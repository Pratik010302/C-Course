#include<iostream>
using namespace std;

class binary
{
    private:
    string s;
    public:
    void read();
    void check();

};

void binary::read(void)
{
    cout<<"\nenter a binary string:"<<endl;
    cin>>s;

}

void binary::check(void)
{
    for ( int i = 0; i < s.length(); i++)
    {
        if(s.at(i)!='0'&& s.at(i)!='1')
        {
            cout<<"\nThe number is not binary..."<<endl;
            exit(0); 

        }
        
            
        
        
    }
    
}

int main()
{
    binary b;
    b.read();
    b.check();
    return 0;
}