#include<iostream>
using namespace std;

int main()
{
    int a=4;
    int *p = &a;
    cout<<"the value at address is"<<*p<<endl;

    int *ptr= new int(4);
    cout<<"the value at address p is:"<<*(ptr);

    float *ptr1 =new float(105.23);
    cout<<"the value of address ptr1 is:"<<*(ptr1)<<endl;

    int *arr=new int [5];
    arr[0]=10;
    arr[1]=50;
    arr[2]=20;
    arr[3]=60;
    arr[4]=40;
    cout<<"the value at address 0 is"<<arr[0]<<endl;
    delete[] arr;
    cout<<"the value at address 2 is:"<<arr[2];


}