#include<iostream>
using namespace std;

int sum(int  a, int b)
    {
        int c=a+b;
        cout<<"\n the value of sum is:"<<c<<endl;

    }

int main()
{
    int x,y;
    cout<<"enter the value of x and y:"<<endl;
    cin>>x>>y;
    sum(x,y);

    return 0;

}