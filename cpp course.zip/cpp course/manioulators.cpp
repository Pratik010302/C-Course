#include<iostream>
#include<iomanip>

using namespace std;
int main()
{
    int a=2;
    int b=68,c=100;
    cout<<"without setw "<<a<<endl;
    cout<<"without setw "<<b<<endl;
    cout<<"without setw "<<c<<endl;

    cout<<"with setw "<<setw(4)<<a<<endl;
    cout<<"with setw "<<setw(4)<<b<<endl;
    cout<<"with setw "<<setw(4)<<c<<endl;
    

    //there are 2 manipulators
    //1.setw is used to set the width of particular length
    //endl is used to set the newline








}