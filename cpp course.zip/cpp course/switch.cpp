#include<iostream>
using namespace std;
int main()
{
    int marks;
    cout<<"enter marks:"<<endl;
    cin>>marks;

    switch ((marks))
    {
       case 1:
       if(marks>90)
       cout<<"A+";
       break;

       case 2:if(marks>80)
       cout<<"A";
       break;

       case 3:if(marks>60)
       cout<<"B";
       break;

       default:
       cout<<"D";

    }
    return 0;

}