#include<iostream>
using namespace std;

class student
{
    int student_id;
    string name;

    public:
    student();     //defaullt constructor
    
    void display()
    {
        cout<<"your id is:"<<student_id<<"name is:"<<name<<endl;

    }

};

student::student()
{
    student_id=101;
    name="pratik";
}

int main()
{

    student s1;
    s1.display();
    return 0;
}