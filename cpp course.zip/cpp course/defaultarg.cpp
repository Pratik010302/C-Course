#include<iostream>
using namespace std;

int moneyreceived(int money,float factor=1.04)
{
    return money*factor;
}

int main()
{
    int money=10000;
    cout<<"if you have"<<money<<"rs"<<"you will get"<<moneyreceived(money)<<"after 1 year"<<endl;
    cout<<"if you have"<<money<<"rs"<<"you will get"<<moneyreceived(money,1.08)<<"after 1 year"<<endl;

    return 0;
}

//at the time first call no argument for factor has send then it will takes default value
// at second call it overrides the value off the factor 