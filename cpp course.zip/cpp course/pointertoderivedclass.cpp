#include<iostream>
using namespace std;

class base
{
    public:
    int var_base;
    
    void display()
    {
        cout<<"the value of base class variable is:"<<var_base<<endl;

    }

};

class derived:public base
{
    public:
    int var_derived;
   
    void display()
    {
        cout<<"the value of base class variable is:"<<var_base<<endl;

        cout<<"the value of derived class variable is:"<<var_derived<<endl;
    }

};


int main()
{ 
    base * base_class_pointer;
    base base_object;

    derived derived_object;
    base_class_pointer = &derived_object;

    base_class_pointer->var_base=50;    //base class pointer setting the value of 
                                        //base class varible
    base_class_pointer->display();       //here base class method will invoked not of derived class
 
    // this method is called as late binding 
    //although base class pointer is pointing to the derived class object but 
    // it invokes the method of base class only because it is the pointer of base class 
    // and invokes the base class method


    derived * derived_class_pointer;
    derived_class_pointer = &derived_object;
    
    derived_class_pointer->var_base=150;
    derived_class_pointer->var_derived=300;
 
    derived_class_pointer->display();          //this will invoke the derived class method


    return 0;
}