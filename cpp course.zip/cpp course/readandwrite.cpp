#include<iostream>
#include<fstream>
#include<string>

using namespace std;
int main()
{
    //opening a file using constructor and writing the content to it
    string st="hello good morning";      
    ofstream of("tut.txt");            //creating object of the ofstream class
    of<<st;                            //displaying the content

    //opening a file and reading the content from it

    string st2;
    ifstream in("tut.txt");
    in>>st2;
    cout<<st2;
    getline(in,st2);


    return 0;
}