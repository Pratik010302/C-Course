#include<iostream>
using namespace std;

class Pratik
{
    int data1,data2;
    public:
    Pratik(int a,int b=0)
    {
        data1=a;
        data2=b;

    }
    void display();


};

void Pratik::display()
{
    cout<<"the value of data1 is:"<<data1<<"the value of data2 is:"<<data2<<endl;
}

int main()
{

    Pratik p(10);        //here default value of b is invoked
    p.display();

    Pratik p2(20,30);   //30 will overrides the value of b 
    p2.display();

    return 0;
}