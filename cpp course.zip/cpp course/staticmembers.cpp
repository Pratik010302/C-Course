#include<iostream>
using namespace std;

class Employee
{

    private:
    int id;
    static int count;
    public:
    void setdata(){
        cout<<"enter your id:"<<endl;
        cin>>id;
        count++;
    }

    void getdata(){
        cout<<"your id is:"<<id << "with count is:"<<count<<endl;
    }

};

int Employee :: count;           //this will execute only ones and updated each time time when setdata function is called




int main()
{
    Employee e1,e2,e3;

    e1.setdata();       //each object of the class shares the single copy of the static member
    e1.getdata();

    e2.setdata();
    e2.getdata();

    e3.setdata();
    e3.getdata();
    return 0;
}