#include<iostream>
#include<string>
using namespace std;

template<class T1=int,class T2=float, class T3= char>

class Sample
{
    public:
    T1  a;
    T2  b;
    T3  c;
    
    Sample(T1 x,T2 y, T3 z)
    {
        a=x;
        b=y;
        c=z;
    }
    void display()
    {
        cout<<"the value of a is:"<<a<<endl;
        cout<<"the value of b is:"<<b<<endl;
        cout<<"the value of c is:"<<c<<endl;

    }


};

int main()
{
    Sample<int , char ,char>obj(4,'p','S');     //these data types specified will overrides the data types specified

    obj.display();
    cout<<endl;

    Sample<>obj2(5.2,4,'A');
    obj2.display();

    return 0;
}

