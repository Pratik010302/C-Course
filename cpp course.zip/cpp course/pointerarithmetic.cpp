#include<iostream>
using namespace std;
int main()
{
    int array[]={10,20,30,40,50};

    int *p=array;   // it will store the value of address of the first element
                    // as the name of the address defines the address of the starting element of the array
    
    cout<<"the value of the array[0] is:"<<*p<<endl;
    cout<<"the value of the array[0] is:"<<*(p+1)<<endl;
    cout<<"the value of the array[0] is:"<<*(p+2)<<endl;
    cout<<"the value of the array[0] is:"<<*(p+3)<<endl;
    cout<<"the value of the array[0] is:"<<*(p+4)<<endl;
     
   
    
    


    return 0;
}