#include <iostream>
using namespace std;

class student
{
protected:
    int roll_number;

public:
    void set_roll_number(int);
    void get_roll_number();
};
void student::set_roll_number(int r)
{
    roll_number = r;
}
void student::get_roll_number()
{
    cout << "\nyour roll number is:" << roll_number << endl;
}

//.........................................

class marks : public student
{
protected:
    float maths;
    float science;

public:
    void set_marks(float, float);
    void get_marks();
};

void marks::set_marks(float m, float s)
{
    maths = m;
    science = s;
}

void marks::get_marks()
{
    cout << "marks obtained in maths are:" << maths << endl;
    cout << "marks  obbatined in the science are:" << science << endl;
}

//...........................................

class result : public marks
{
protected:
    float percentage;

public:
    void Display()
    {

        get_roll_number();
        get_marks();
        cout << "your percentage are:" << (maths + science) / 2;
    }
};

int main()
{
    result r;
    r.set_roll_number(101);
    r.set_marks(98.2, 96.5);
    r.Display();

    return 0;
}