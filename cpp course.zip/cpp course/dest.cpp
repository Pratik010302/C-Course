#include<iostream>
using namespace std;

int count=0;      //global variable

class num
{
   public:
   num()
   {
    count++;
    cout<<"\n this is the  time when constructor is  called for  object "<<count<<endl;
   } 

   ~num()
   {
     cout<<"\n this is the time when destructor is  called for object"<<count<<endl;
     count--;


   }

};


 int main()
 {
    cout<<"\nwe are inside the main function"<<endl;
    cout<<"\ncreating the object one"<<endl;
    num n1;
    {
        cout<<"\n entering in the block"<<endl;
        cout<<"\n creating another two object "<<endl;
        num n2,n3;
        cout<<"\nexit";
    }

    cout<<"\nback to main.......";
    

    return 0;
 }