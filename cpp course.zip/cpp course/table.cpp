#include<iostream>
using namespace std;
int main()
{
    int i,n;
    cout<<"enter a number:";
    cin>>n;
    for(i=1;i<11;i++)
    {
        cout<<n<<"*"<<i<<"="<<n*i<<endl;

    }
    return 0;
}