#include<iostream>
#include<string>
#include<fstream>
using namespace std;
int main()
{
    string st = "Hello Pratik";
    //opening a file using constructor and eriting content to it
    ofstream out ("sample60.txt");   //opening file in write mode(out)
    out<<st;                        //writing the content of st
    

    // opening the file using constructor and reading content from it

    string st2;
    ifstream in("sample2.txt");  //opening the file in read mode
    in>>st2;                     //storing the coontent into the st2
    getline(in,st2);             // getline function is used to store the entire line otherwise it will stores only a first string and no further spaces and charcters will store 
    cout<<st2;          //it simply displays what it reads from the file;

    return 0;
}

/*
1. out is the object of ofstream class 
2. in is the oject of ifstream class
3. ifstream class is used to read content from the file
4. ofstream class is used to write the content to the file
5. both ifstream and ofstream classes are derive dfrom fstream class
6. fstream class is used for both input and output stream
7. stream is basically a channel through which the data can be transferred from one file to another
*/