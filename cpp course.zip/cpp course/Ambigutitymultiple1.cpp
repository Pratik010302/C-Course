#include<iostream>
using namespace std;

class Base1
{
    public:
    void message()
    {
        cout<<"hello how are you?"<<endl;
    }

};

class Base2
{
    public:
    void message()
    {
        cout<<"kaise ho?"<<endl;

    }

};

class Derived : public Base1 , public Base2
{
   int a;
   public:
   void message()
   {
    Base1::message();
   };
};

int main()
{
    Base1 b1;
    Base2 b2;
    b1.message();     //it will invoke the base1 class method
    b2.message();     // it will invoke base2 class method

    Derived d;
    //d.message();     //ambiguty is created because it does not know which message method has to invoke
     
    d.message();

    return 0;
}