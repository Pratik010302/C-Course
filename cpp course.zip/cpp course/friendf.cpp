#include<iostream>
using namespace std;

class Complex
{
    int a,b;
    friend Complex sumnumber(Complex o1,Complex o2); // has given the access to the friend function

    public:
    void setnumber(int n1,int n2)
    {
        a=n1;
        b=n2;
    }
    
    void printnumber()
    {
        cout<<"your complex number is:"<<a<<"+"<<b<<"i"<<endl;
    }
    
};

Complex sumnumber(Complex o1,Complex o2)     //friend function is always defined outside the class
{
    Complex o3;
    o3.setnumber((o1.a+o2.a),(o1.b+o2.b));
    return o3;

}




int main()
{
    Complex c1,c2,sum;
    c1.setnumber(4, 2);
    c1.printnumber();

    c2.setnumber(6,3);
    c2.printnumber();

    sum=sumnumber(c1,c2);
    sum.printnumber();


    return 0;
}