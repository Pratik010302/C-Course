#include<iostream>
using namespace std;

class Complex
{

    int a,b;

    public:
    Complex(void);

    void PrintNumber()
    {
        cout<<"\n Your complex number is:"<<a<<"+"<<b<<"i"<<endl;
    }
};

Complex::Complex(void)
{
    a=10;
    b=20;
}


int main()
{
     Complex c1,c2;
     c1.PrintNumber();
     c2.PrintNumber();
    return 0;
}