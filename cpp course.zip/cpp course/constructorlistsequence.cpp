#include<iostream>
using namespace std;

class Test
{
    int a , b;
    public:
    //Test(int i, int j):a(i),b(j)                      // here all  the operations in the sequence of and b are executed // but if order gets changed it will not executed
    Test(int i, int j):a(i),b(i+j)      
    // Test(int i, int j):b(j),(i)               // this will not work
    
    {
        cout<<"constructoe executed:"<<endl;
        cout<<"the value of a is:"<<a<<endl;
        cout<<"the value of b is:"<<b<<endl;
    }
};

int main()
{
    Test t(4,6);
    return 0;
}