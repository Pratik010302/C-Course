#include<iostream>
using namespace std;

class base1
{
    protected:
    int base1int;
    public:
    void set_base1int(int);
};

void base1::set_base1int(int r1)
{
    base1int=r1;
}

class base2
{
    protected:
    int base2int;
    public:
    void set_base2int(int);
};
void base2::set_base2int(int r2)
{
    base2int=r2;

}

class base3
{
    protected:
    int base3int;
    public:
    void set_base3int(int);
};
void base3::set_base3int(int r3)
{
    base3int=r3;

}


class derived:public base1, public base2, public base3
{
    public:
    void show();

};
void derived::show()
{
    cout<<"\nThe value of 1st integer is:"<<base1int<<endl;
    cout<<"\nThe value of 2nd integer is:"<<base2int<<endl;
    cout<<"\nThe value of 3rd integer is:"<<base3int<<endl;
   
    cout<<"\nThe sum of these two integeres is:"<<(base1int+base2int+base3int)<<endl;

}


int main()
{

    derived d;
    d.set_base1int(105);
    d.set_base2int(103);
    d.set_base3int(100);
   
    d.show();
    return 0;
}