#include<iostream>
using namespace std;
int main()
{

    cout<<" Hello my name is pratik wagh"<<endl;
    cout<<"\ngood bye";
    return 0;
}
