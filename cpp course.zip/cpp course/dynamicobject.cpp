#include<iostream>
using namespace std;

class BankDeposit
{
    int principal;
    int years;
    float rate;
    float returnvalue;

    public:
    BankDeposit(){}
    BankDeposit(int p,int y,float r);   // for floating point intererst rate
    BankDeposit(int p,int y, int r);    // for integer(percentage) interest rate
    void show();

};

BankDeposit::BankDeposit(int p, int y, float r)
{
    principal = p;
    rate = r;
    years =y;
    returnvalue= principal;
    for (int i = 0; i < y; i++)
    {
        returnvalue = returnvalue * (1+rate);
    }
    
}


BankDeposit::BankDeposit(int p, int y,int r)
{
    principal = p;
    rate = float(r)/100;
    years =y ;
    returnvalue = principal;
    for (int i = 0; i < y; i++)
    {
        returnvalue = returnvalue*(1+rate);
    }
    
}

void BankDeposit::show()
{
    cout<<"\n principal amount was"<<principal<<"\n after "<<years<<" years amount will be "<<returnvalue;
}

int main()
{
    BankDeposit bd1,bd2,bd3;

    int p, y;
    float r;
    int R;

    cout<<"\nenter the value of principal amount,years and rate: "<<endl;
    cin>>p>>y>>r;
    bd1 = BankDeposit(p,y,r);
    bd1.show();


    cout<<"\nenter the value of principal amount , rate of interest anf period"<<endl;
    cin>>p>>R>>y;
    bd2 = BankDeposit(p,y,R);
    bd2.show();

    return 0;
}