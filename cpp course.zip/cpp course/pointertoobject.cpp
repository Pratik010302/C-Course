#include<iostream>
using namespace std;

class Complex
{
    int real ,imag;
    public:
    void setdata(int r,int i )
    {
       real=r;
       imag=i;
    }

    void getdata()
    {
        cout<<"the value of real part is:"<<real<<endl;
        cout<<"the value of imaginary part is:"<<imag<<endl;
    }

};

int main()
{
    Complex o1;
    int n1,n2;
    cout<<"enter real part:"<<endl;
    cin>>n1;
    cout<<"Enter imaginary part:"<<endl;
    cin>>n2;

    //o1.setdata(n1,n2);
    //o1.getdata();

    Complex *ptr=&o1;         //pointer to the object
    (*ptr).setdata(n1,n2);    //using pointer method invocation is done
    //(*ptr).getdata();      this can be also treated as  


    ptr->getdata();         //useing arrow operator method can also invoked it simply points 
                            //to the object
    return 0;
}