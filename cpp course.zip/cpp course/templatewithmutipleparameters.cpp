#include<iostream>
#include<string>
using namespace std;

/*
1. when it is not fixed that which data type is going to be used then make a use paramet-
terized template
2. this parametrized template will help us to define a single class that performs the function 
    any kind of data type later
*/


template< class T1, class T2>      //tempalte with multiple parameters
class Sample
{
    public:
    T1 data1;
    T2 data2;

    //creating a constructor
    Sample(T1 a, T2 b)
    {
        data1 = a;
        data2 = b;
    }

    void display()
    {
        cout<<"the value of data 1 is:"<<data1<<endl;
        cout<<"the value of data 2 is:"<<data2<<endl;
    }

};
int main()
{
    Sample<char,float> obj('p',52.31);   //deciding which parameters are used during run time
    obj.display();
    return 0;
}