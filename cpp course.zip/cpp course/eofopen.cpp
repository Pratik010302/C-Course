#include<iostream>
#include<string>
#include<fstream>
using namespace std;
int main()
{
    //opening a file using open method
    ofstream out;
    out.open("tut2.txt");     //opening a file
    out<<"hello"<<endl;       //writing a content    
    out<<"this is me:"<<endl;
    out<<"my name si pratik:"<<endl;
    out.close();               //closing the file

    //creating a object of ifstream anf open file using open method

    ifstream in;
    in.open("tut2.txt");
    // string st,st1;
    // in>>st>>st1;
    // cout<<st<<endl;    //now these st and st1 will give only two starting strings 
    //                    //to get entire lines we make a use of getline function

    // cout<<st1;
    

    string st;
    while(in.eof()==0)
    {
        getline(in,st);
        cout<<st<<endl;

    }

    in.close()  ;      //by default file gets close
    in.eof();       
    cout<<( in.eof()==0);    //check that end of file is reached or not
    return 0; 
}