#include<iostream>
using namespace std;

class Employee
{
    int id ;
    string name;
    public:
    Employee(int n1,string n2)   //constructor
    {
        id=n1;
        name=n2;
    }

    void display()
    {
        cout<<"your id is:"<<id<<"your name is :"<<name<<endl;
    }

};

int main()
{
    int n1;
    string n2;

    cout<<"enter your id:"<<endl;
    cin>>n1;
    cout<<"enter your name:"<<endl;
    cin>>n2;

    Employee e1(n1,n2);
    e1.display();


    return 0;
}