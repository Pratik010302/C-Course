#include<iostream>
using namespace std;

int main()
{
    int a=3;
    int *b=&a;
    cout<<&a<<endl;
    cout<<b<<endl;
    cout<<*b;

    int **c=&b;
    cout<<"the address b is:"<<&b<<endl;
    cout<<"the address of b is:"<<c<<endl;
    cout<<"the value at address  c is:"<<*c<<endl;

    return 0;
}

