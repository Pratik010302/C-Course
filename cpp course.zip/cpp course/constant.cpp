#include<iostream>
using namespace std;
int main()
{
    int a=10;
    float b=25.2;
    cout<<"before changing:"<<"a="<<a<<"b="<<b;
     a=25;
     b=64.5;
    cout<<"after changing:"<<"a="<<a<<"b="<<b;

    //since variable values can be changed so to avoid it we make use of constants

    const int h=64;
    //h=52;    //as it is constant cannot be changed
    cout<<h;


    return 0;
}