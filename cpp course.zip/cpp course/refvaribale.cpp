#include<iostream>
using namespace std;

int main()
{

    int x=3;
    int &y=x;
    cout<<x<<endl;
    cout<<y;

    return 0;
}