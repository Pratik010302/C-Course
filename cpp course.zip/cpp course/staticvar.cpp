#include<iostream>
using namespace std;

int sum(int a,int b)
{
   static int c=0;     //this will execute only one time
   c+=1;                //at each execution value of c will incremented by 1
   //with static variable inline functions are not used
   return a+b*c;
   
}

int main()
{
    int a,b;
    cout<<"enter the value os a and b:"<<endl;
    cin>>a>>b;
    cout<<sum(a,b)<<endl;
    cout<<sum(a,b)<<endl;
    cout<<sum(a,b)<<endl;
    return 0;
}