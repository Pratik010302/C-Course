#include<iostream>
using namespace std;

class Complex
{
    int a,b;
    public:

    Complex(int x,int y);
    
    void Printnumber()
    {
       cout<<"\nYour number is:"<<a<<"+"<<b<<"i"<<endl;
    }

};

Complex::Complex(int x, int y)
{
    a=x;
    b=y;
}


int main()
{
    Complex c1(4,5);
    Complex c2=Complex(10,20);

    c1.Printnumber();
    c2.Printnumber();

    return 0;

}