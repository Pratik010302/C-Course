#include<iostream>
using namespace std;

int sum(int,int);    //this is allowed as funtion prototype


int main()
{
   int a,b;
   cout<<"enter value of a:"<<endl;
   cin>>a;
   cout<<"enter value of b:"<<endl;
   cin>>b;
   int result=sum(a,b);   //actual parameters
   cout<<result;
}

int sum(int num1,int num2)   //formal parameters
{
    int c=num1+num2;
    return c;
}