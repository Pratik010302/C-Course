#include<iostream>
using namespace std;

int volume(float r, float h)
{
    return (3.14*r*r*h);

}

int volume(float l,float b,float h)
{
    return (l*b*h);
}

int volume(int a)
{
    return (a*a*a);


}

int main()
{
    cout<<"\nThe volume of a cylinder is:"<<volume(2.5,3.6)<<endl;
    cout<<"\nThe volume of a cube is:"<<volume(10)<<endl;
    cout<<"\nthe volume of a cuboid is:"<<volume(4.1,2.5,1.5)<<endl;

        
    return 0;
}